﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btnOfficials = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.btnResidents = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.btnBusinessPermit = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel3 = New System.Windows.Forms.ToolStripLabel()
        Me.btnCertifications = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel6 = New System.Windows.Forms.ToolStripLabel()
        Me.btnIndigencies = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel7 = New System.Windows.Forms.ToolStripLabel()
        Me.btnSeniors = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel5 = New System.Windows.Forms.ToolStripLabel()
        Me.btnUsers = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel4 = New System.Windows.Forms.ToolStripLabel()
        Me.btnExit = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnOfficials, Me.ToolStripLabel1, Me.btnResidents, Me.ToolStripLabel2, Me.btnBusinessPermit, Me.ToolStripLabel3, Me.btnCertifications, Me.ToolStripLabel6, Me.btnIndigencies, Me.ToolStripLabel7, Me.btnSeniors, Me.ToolStripLabel5, Me.btnUsers, Me.ToolStripLabel4, Me.btnExit})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(957, 25)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btnOfficials
        '
        Me.btnOfficials.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnOfficials.Image = CType(resources.GetObject("btnOfficials.Image"), System.Drawing.Image)
        Me.btnOfficials.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnOfficials.Name = "btnOfficials"
        Me.btnOfficials.Size = New System.Drawing.Size(106, 22)
        Me.btnOfficials.Text = "Barangay Officials"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel1.Text = "|"
        '
        'btnResidents
        '
        Me.btnResidents.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnResidents.Image = CType(resources.GetObject("btnResidents.Image"), System.Drawing.Image)
        Me.btnResidents.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnResidents.Name = "btnResidents"
        Me.btnResidents.Size = New System.Drawing.Size(113, 22)
        Me.btnResidents.Text = "Barangay Residents"
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel2.Text = "|"
        '
        'btnBusinessPermit
        '
        Me.btnBusinessPermit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnBusinessPermit.Image = CType(resources.GetObject("btnBusinessPermit.Image"), System.Drawing.Image)
        Me.btnBusinessPermit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnBusinessPermit.Name = "btnBusinessPermit"
        Me.btnBusinessPermit.Size = New System.Drawing.Size(94, 22)
        Me.btnBusinessPermit.Text = "Business Permit"
        '
        'ToolStripLabel3
        '
        Me.ToolStripLabel3.Name = "ToolStripLabel3"
        Me.ToolStripLabel3.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel3.Text = "|"
        '
        'btnCertifications
        '
        Me.btnCertifications.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnCertifications.Image = CType(resources.GetObject("btnCertifications.Image"), System.Drawing.Image)
        Me.btnCertifications.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnCertifications.Name = "btnCertifications"
        Me.btnCertifications.Size = New System.Drawing.Size(81, 22)
        Me.btnCertifications.Text = "Certifications"
        '
        'ToolStripLabel6
        '
        Me.ToolStripLabel6.Name = "ToolStripLabel6"
        Me.ToolStripLabel6.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel6.Text = "|"
        '
        'btnIndigencies
        '
        Me.btnIndigencies.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnIndigencies.Image = CType(resources.GetObject("btnIndigencies.Image"), System.Drawing.Image)
        Me.btnIndigencies.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnIndigencies.Name = "btnIndigencies"
        Me.btnIndigencies.Size = New System.Drawing.Size(71, 22)
        Me.btnIndigencies.Text = "Indigencies"
        '
        'ToolStripLabel7
        '
        Me.ToolStripLabel7.Name = "ToolStripLabel7"
        Me.ToolStripLabel7.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel7.Text = "|"
        '
        'btnSeniors
        '
        Me.btnSeniors.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnSeniors.Image = CType(resources.GetObject("btnSeniors.Image"), System.Drawing.Image)
        Me.btnSeniors.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnSeniors.Name = "btnSeniors"
        Me.btnSeniors.Size = New System.Drawing.Size(49, 22)
        Me.btnSeniors.Text = "Seniors"
        '
        'ToolStripLabel5
        '
        Me.ToolStripLabel5.Name = "ToolStripLabel5"
        Me.ToolStripLabel5.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel5.Text = "|"
        '
        'btnUsers
        '
        Me.btnUsers.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnUsers.Image = CType(resources.GetObject("btnUsers.Image"), System.Drawing.Image)
        Me.btnUsers.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnUsers.Name = "btnUsers"
        Me.btnUsers.Size = New System.Drawing.Size(39, 22)
        Me.btnUsers.Text = "Users"
        '
        'ToolStripLabel4
        '
        Me.ToolStripLabel4.Name = "ToolStripLabel4"
        Me.ToolStripLabel4.Size = New System.Drawing.Size(10, 22)
        Me.ToolStripLabel4.Text = "|"
        '
        'btnExit
        '
        Me.btnExit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnExit.Image = CType(resources.GetObject("btnExit.Image"), System.Drawing.Image)
        Me.btnExit.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(29, 22)
        Me.btnExit.Text = "Exit"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(957, 548)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Name = "frmMain"
        Me.Text = "Barangay Information System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents btnOfficials As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents btnResidents As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel2 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents btnBusinessPermit As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel4 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents btnExit As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel3 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents btnCertifications As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel6 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents btnIndigencies As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel7 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents btnSeniors As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripLabel5 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents btnUsers As System.Windows.Forms.ToolStripButton

End Class
