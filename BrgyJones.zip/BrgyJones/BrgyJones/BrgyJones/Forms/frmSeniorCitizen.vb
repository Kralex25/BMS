﻿Imports System.Windows.Forms

Public Class frmSeniorCitizen
    Dim ID As Integer
    Dim Sen As New SeniorsClass
    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        txtbirthdate.Text = DateTimePicker1.Value
    End Sub

    Sub fillList()
        Dim list As List(Of SeniorsClass) = Sen.GetAllSeniors
        With lvList
            .Items.Clear()
            For Each post As SeniorsClass In list
                Dim item As New ListViewItem
                item.Text = post.SeniorID
                item.SubItems.Add(post.LastName)
                item.SubItems.Add(post.FirstName)
                item.SubItems.Add(post.MI)
                item.SubItems.Add(post.Address)
                item.SubItems.Add(post.Birthdate)
                item.SubItems.Add(post.Stipend)
                .Items.Add(item)
            Next
        End With
    End Sub

    Sub fillSenior()
        Sen.LastName = txtLastName.Text
        Sen.FirstName = txtFirstName.Text
        Sen.MI = txtMI.Text
        Sen.Address = txtAddress.Text
        Sen.Birthdate = txtbirthdate.Text
        Sen.Stipend = txtStipend.Text
    End Sub


    Sub fillControls()
        clear()
        Dim list As ArrayList = Sen.GetSeniorByID(ID)
        For Each post As SeniorsClass In list
            ID = post.SeniorID
            txtLastName.Text = post.LastName
            txtFirstName.Text = post.FirstName
            txtMI.Text = post.MI
            txtAddress.Text = post.Address
            txtbirthdate.Text = post.Birthdate
            txtStipend.Text = post.Stipend
        Next
    End Sub

    Sub clear()
        Dim a As Control
        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = String.Empty
            End If
        Next
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        ID = Nothing
        clear()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ID = Nothing
        fillSenior()
        Sen.addSenior()
        clear()
        fillList()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If Not ID = Nothing Then
            fillSenior()
            Sen.updateSenior(ID)
            fillList()
            ID = Nothing
            clear()
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Not ID = Nothing Then
            Sen.deleteSenior(ID)
            fillList()
            clear()
            ID = Nothing
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub lvList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvList.SelectedIndexChanged
        If lvList.SelectedItems.Count > 0 Then
            ID = CInt(lvList.SelectedItems(0).Text)
        End If
        fillControls()
    End Sub

    Private Sub frmSeniorCitizen_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clear()
    End Sub

    Private Sub frmSeniorCitizen_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillList()
    End Sub
End Class
