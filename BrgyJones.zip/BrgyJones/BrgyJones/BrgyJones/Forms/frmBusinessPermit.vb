﻿Imports Microsoft.Reporting.WinForms
Public Class frmBusinessPermit
    Dim Bus As New BusinessClass
    Dim ID As Integer

    Private Sub frmBusinessPermit_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clear()
    End Sub
    Private Sub frmBusinessPermit_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillList()
    End Sub

    Sub fillList()
        Dim list As List(Of BusinessClass) = Bus.GetAllBusinesses
        With lvList
            .Items.Clear()
            For Each post As BusinessClass In list
                Dim item As New ListViewItem
                item.Text = post.BusinessID
                item.SubItems.Add(post.Name)
                item.SubItems.Add(post.Owner)
                item.SubItems.Add(post.CTC)
                item.SubItems.Add(post.CDateIssue)
                item.SubItems.Add(post.PlaceIssued)
                item.SubItems.Add(post.BDateIssued)
                .Items.Add(item)
            Next
        End With
    End Sub

    Sub fillBusiness()
        Bus.Name = txtBusinessName.Text
        Bus.Owner = txtOwner.Text
        Bus.CTC = txtCTC.Text
        Bus.CDateIssue = txtDateIssued.Text
        Bus.PlaceIssued = txtPlaceIssued.Text
        Bus.BDateIssued = txtbdateissue.Text
    End Sub

    Sub fillControls()
        clear()
        Dim list As ArrayList = Bus.GetBusinessByID(ID)
        For Each post As BusinessClass In list
            ID = post.BusinessID
            txtBusinessName.Text = post.Name
            txtOwner.Text = post.Owner
            txtCTC.Text = Bus.CTC
            txtDateIssued.Text = Bus.CDateIssue
            txtPlaceIssued.Text = Bus.PlaceIssued
            txtbdateissue.Text = Bus.BDateIssued
        Next
    End Sub

    Private Sub lvList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvList.SelectedIndexChanged
        If lvList.SelectedItems.Count > 0 Then
            ID = CInt(lvList.SelectedItems(0).Text)
        End If
        fillControls()
    End Sub

    Sub clear()
        Dim a As Control
        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = String.Empty
            End If
        Next
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        ID = Nothing
        clear()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ID = Nothing
        fillBusiness()
        Bus.addBusiness()
        clear()
        fillList()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If Not ID = Nothing Then
            fillBusiness()
            Bus.updateBusiness(ID)
            fillList()
            ID = Nothing
            clear()
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Not ID = Nothing Then
            Bus.deleteBusiness(ID)
            fillList()
            clear()
            ID = Nothing
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub DateTimePicker1_ValueChanged_1(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        txtbdateissue.Text = DateTimePicker1.Value
    End Sub

    Private Sub DateTimePicker2_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker2.ValueChanged
        txtDateIssued.Text = DateTimePicker2.Value
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        If Not ID = Nothing Then
            Dim bus As New BusinessClass
            Dim rptSource As String = "BrgyJones.rptBusinessPermit.rdlc"
            Dim list As ArrayList = bus.GetBusinessByID(ID)
            Dim rds As New ReportDataSource
            With frmPrint
                With .rvPrint
                    .LocalReport.ReportEmbeddedResource = rptSource
                    rds.Name = "DataSet1"
                    rds.Value = list
                    .LocalReport.DataSources.Clear()
                    .LocalReport.DataSources.Add(rds)
                    .LocalReport.Refresh()
                    .DocumentMapCollapsed = True
                    .SetDisplayMode(DisplayMode.PrintLayout)
                    .RefreshReport()
                End With
                .ShowDialog(Me)
            End With
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub
End Class