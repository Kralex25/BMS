﻿Imports System.Windows.Forms

Public Class frmPrint

    Private Sub frmPrint_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.rvPrint.RefreshReport()
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class
