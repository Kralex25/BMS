﻿Public Class frmMain

    Private Sub btnResidents_Click(sender As Object, e As EventArgs) Handles btnResidents.Click
        Dim residents As New frmResidents
        residents.Show(Me)
    End Sub

    Private Sub btnOfficials_Click(sender As Object, e As EventArgs) Handles btnOfficials.Click
        Dim officials As New frmBrgyOfficials
        officials.ShowDialog(Me)
    End Sub


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Application.Exit()
    End Sub

    Private Sub btnBusinessPermit_Click(sender As Object, e As EventArgs) Handles btnBusinessPermit.Click
        frmBusinessPermit.ShowDialog(Me)
    End Sub

    Private Sub btnCertifications_Click(sender As Object, e As EventArgs) Handles btnCertifications.Click
        frmCertification.ShowDialog(Me)
    End Sub

    Private Sub btnIndigencies_Click(sender As Object, e As EventArgs) Handles btnIndigencies.Click
        frmIndigencies.ShowDialog(Me)
    End Sub

    Private Sub btnSeniors_Click(sender As Object, e As EventArgs) Handles btnSeniors.Click
        frmSeniorCitizen.ShowDialog(Me)
    End Sub

    Private Sub btnUsers_Click(sender As Object, e As EventArgs) Handles btnUsers.Click
        frmUsers.ShowDialog(Me)
    End Sub
End Class
