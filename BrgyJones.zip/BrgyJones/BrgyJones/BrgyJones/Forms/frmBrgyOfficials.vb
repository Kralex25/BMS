﻿Public Class frmBrgyOfficials
    Dim official As New OfficialsClass
    Dim ID As Integer
    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        Dim d1, d2 As Date
        Dim days, months, years As Long

        d1 = DateTimePicker1.Value.ToShortDateString
        d2 = Now.ToShortDateString

        years = Year(d1)
        months = Month(d1)
        days = d1.Day

        years = Year(d2) - years
        months = Month(d2) - months
        days = d2.Day - days

        If Math.Sign(days) = -1 Then
            days = 30 - Math.Abs(days)
            months = months - 1
        End If

        If Math.Sign(months) = -1 Then
            months = 12 - Math.Abs(months)
            years = years - 1
        End If

        txtage.Text = years.ToString
        txtbdate.Text = DateTimePicker1.Value
    End Sub

    Private Sub frmBrgyOfficials_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clear()
    End Sub

    Private Sub frmBrgyOfficials_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillList()
    End Sub

    Sub fillList()
        Dim list As List(Of OfficialsClass) = official.GetAllOfficials
        With lvlist
            .Items.Clear()
            For Each post As OfficialsClass In list
                Dim item As New ListViewItem
                item.Text = post.ID
                item.SubItems.Add(post.Lastname)
                item.SubItems.Add(post.Firstname)
                item.SubItems.Add(post.MI)
                item.SubItems.Add(post.CivilStatus)
                item.SubItems.Add(post.Birthdate)
                item.SubItems.Add(post.Age)
                item.SubItems.Add(post.Gender)
                item.SubItems.Add(post.Address)
                item.SubItems.Add(post.Position)
                .Items.Add(item)
            Next
        End With
    End Sub

    Sub fillControls()
        Dim list As ArrayList = official.GetAllOfficialByID(ID)
        For Each post As OfficialsClass In list
            ID = post.ID
            txtfname.Text = post.Firstname
            txtlname.Text = post.Lastname
            txtmi.Text = post.MI
            cbgender.Text = post.Gender
            txtbdate.Text = post.Birthdate
            txtage.Text = post.Age
            txtaddress.Text = post.Address
            txtcontact.Text = post.Contact
            cbCivil.Text = post.CivilStatus
            txtemail.Text = post.Email
            cbPosition.Text = post.Position
        Next
    End Sub

    Sub fillofficials()
        official.Firstname = txtfname.Text
        official.Lastname = txtlname.Text
        official.MI = txtmi.Text
        official.Gender = cbgender.Text
        official.Birthdate = txtbdate.Text
        official.Age = txtage.Text
        official.Address = txtaddress.Text
        official.Contact = txtcontact.Text
        official.CivilStatus = cbCivil.Text
        official.Email = txtemail.Text
        official.Position = cbPosition.Text
    End Sub

    Private Sub lvlist_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvlist.SelectedIndexChanged
        If lvlist.SelectedItems.Count > 0 Then
            ID = CInt(lvlist.SelectedItems(0).Text)
        End If
        fillControls()
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        ID = Nothing
        clear()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ID = Nothing
        fillofficials()
        official.addOfficial()
        clear()
        fillList()
    End Sub
    Sub clear()
        Dim a As Control
        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = String.Empty
            End If
        Next
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If Not ID = Nothing Then
            fillofficials()
            official.updateOfficial(ID)
            fillList()
            ID = Nothing
            clear()
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Not ID = Nothing Then
            official.deleteOfficial(ID)
            fillList()
            clear()
            ID = Nothing
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub
End Class