﻿Imports System.Windows.Forms
Imports Microsoft.Reporting.WinForms
Public Class frmIndigencies
    Dim Ind As New IndigenciesClass
    Dim ID As Integer
    Private Sub DateTimePicker2_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker2.ValueChanged
        txtDateIssued.Text = DateTimePicker2.Value
    End Sub

    Private Sub frmIndigencies_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clear()
    End Sub

    Private Sub frmIndigencies_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillList()
    End Sub

    Sub fillList()
        Dim list As List(Of IndigenciesClass) = Ind.GetAllIndigencies
        With lvList
            .Items.Clear()
            For Each post As IndigenciesClass In list
                Dim item As New ListViewItem
                item.Text = post.IndigencyID
                item.SubItems.Add(post.Applicant)
                item.SubItems.Add(post.DateIssued)
                .Items.Add(item)
            Next
        End With
    End Sub

    Sub fillIndigency()
        Ind.Applicant = txtApplicant.Text
        Ind.DateIssued = txtDateIssued.Text
    End Sub

    Sub fillControls()
        clear()
        Dim list As ArrayList = Ind.GetIndigenciesByID(ID)
        For Each post As IndigenciesClass In list
            ID = post.IndigencyID
            txtApplicant.Text = post.Applicant
            txtDateIssued.Text = post.DateIssued
        Next
    End Sub

    Private Sub lvList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvList.SelectedIndexChanged
        If lvList.SelectedItems.Count > 0 Then
            ID = CInt(lvList.SelectedItems(0).Text)
        End If
        fillControls()
    End Sub

    Sub clear()
        Dim a As Control
        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = String.Empty
            End If
        Next
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        ID = Nothing
        clear()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ID = Nothing
        fillIndigency()
        Ind.addIndigency()
        clear()
        fillList()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If Not ID = Nothing Then
            fillIndigency()
            Ind.updateIndigency(ID)
            fillList()
            ID = Nothing
            clear()
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Not ID = Nothing Then
            Ind.deleteIndigency(ID)
            fillList()
            clear()
            ID = Nothing
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        If Not ID = Nothing Then
            Dim bus As New BusinessClass
            Dim rptSource As String = "BrgyJones.rptIndigency.rdlc"
            Dim list As ArrayList = bus.GetBusinessByID(ID)
            Dim rds As New ReportDataSource
            With frmPrint
                With .rvPrint
                    .LocalReport.ReportEmbeddedResource = rptSource
                    rds.Name = "DataSet1"
                    rds.Value = list
                    .LocalReport.DataSources.Clear()
                    .LocalReport.DataSources.Add(rds)
                    .LocalReport.Refresh()
                    .DocumentMapCollapsed = True
                    .SetDisplayMode(DisplayMode.PrintLayout)
                    .RefreshReport()
                End With
                .ShowDialog(Me)
            End With
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

End Class
