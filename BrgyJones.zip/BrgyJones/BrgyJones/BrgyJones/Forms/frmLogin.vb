﻿Public Class frmLogin
    Dim user As New UsersClass
    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        If user.LogUser(txtUname.Text, txtPword.Text) Then
            Me.Hide()
            frmMain.Show()
        Else
            MsgBox("Invalid Username or Password", MsgBoxStyle.Critical)
            txtUname.Clear()
            txtPword.Clear()
            txtUname.Focus()
            Exit Sub
        End If
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

End Class
