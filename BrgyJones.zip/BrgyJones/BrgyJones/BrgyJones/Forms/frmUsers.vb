﻿Imports System.Windows.Forms

Public Class frmUsers
    Dim ID As Integer
    Dim User As New UsersClass

    Private Sub frmUsers_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clear()
    End Sub
   
    Private Sub frmUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillList()
    End Sub
    Sub fillList()
        Dim list As List(Of UsersClass) = User.GetAllUsers
        With lvList
            .Items.Clear()
            For Each post As UsersClass In list
                Dim item As New ListViewItem
                item.Text = post.UserID
                item.SubItems.Add(post.Username)
                item.SubItems.Add(post.Password)
                .Items.Add(item)
            Next
        End With
    End Sub

    Sub fillUser()
        User.Username = txtUsername.Text
        User.Password = txtPassword.Text
    End Sub


    Sub fillControls()
        clear()
        Dim list As ArrayList = User.GetUserByID(ID)
        For Each post As UsersClass In list
            ID = post.UserID
            txtUsername.Text = post.Username
            txtPassword.Text = post.Password
        Next
    End Sub

    Sub clear()
        Dim a As Control
        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = String.Empty
            End If
        Next
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        ID = Nothing
        clear()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ID = Nothing
        fillUser()
        User.addUser()
        clear()
        fillList()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If Not ID = Nothing Then
            fillUser()
            User.updateUser(ID)
            fillList()
            ID = Nothing
            clear()
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Not ID = Nothing Then
            User.deleteUser(ID)
            fillList()
            clear()
            ID = Nothing
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub lvList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvList.SelectedIndexChanged
        If lvList.SelectedItems.Count > 0 Then
            ID = CInt(lvList.SelectedItems(0).Text)
        End If
        fillControls()
    End Sub
End Class
