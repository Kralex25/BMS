﻿Imports System.Windows.Forms
Imports Microsoft.Reporting.WinForms
Public Class frmCertification
    Dim ID As Integer
    Dim cert As New CertificationsClass
    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        txtdateissue.Text = DateTimePicker1.Value
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        ID = Nothing
        clear()
    End Sub

    Sub fillList()
        Dim list As List(Of CertificationsClass) = cert.GetAllCertifications
        With lvList
            .Items.Clear()
            For Each post As CertificationsClass In list
                Dim item As New ListViewItem
                item.Text = post.CertificationID
                item.SubItems.Add(post.Applicant)
                item.SubItems.Add(post.CivilStatus)
                item.SubItems.Add(post.Length)
                item.SubItems.Add(post.DateIssued)
                .Items.Add(item)
            Next
        End With
    End Sub

    Sub fillCertification()
        cert.Applicant = txtApplicant.Text
        cert.CivilStatus = cbCivilStatus.Text
        cert.Length = cbLength.Text
        cert.DateIssued = txtdateissue.Text
    End Sub


    Sub fillControls()
        clear()
        Dim list As ArrayList = cert.GetCertificationByID(ID)
        For Each post As CertificationsClass In list
            ID = post.CertificationID
            txtApplicant.Text = post.Applicant
            cbCivilStatus.Text = post.CivilStatus
            cbLength.Text = post.Length
            txtdateissue.Text = post.DateIssued
        Next
    End Sub

    Sub clear()
        Dim a As Control
        For Each a In Me.Controls
            If TypeOf a Is TextBox Then
                a.Text = String.Empty
            End If
        Next
    End Sub

    Private Sub frmCertification_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        clear()
    End Sub

    Private Sub frmCertification_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillList()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ID = Nothing
        fillCertification()
        cert.addCertification()
        clear()
        fillList()
    End Sub

    Private Sub lvList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvList.SelectedIndexChanged
        If lvList.SelectedItems.Count > 0 Then
            ID = CInt(lvList.SelectedItems(0).Text)
        End If
        fillControls()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        If Not ID = Nothing Then
            fillCertification()
            cert.updateCertification(ID)
            fillList()
            ID = Nothing
            clear()
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        If Not ID = Nothing Then
            Dim bus As New BusinessClass
            Dim rptSource As String = "BrgyJones.rptCertification.rdlc"
            Dim list As ArrayList = cert.GetCertificationByID(ID)
            Dim rds As New ReportDataSource
            With frmPrint
                With .rvPrint
                    .LocalReport.ReportEmbeddedResource = rptSource
                    rds.Name = "DataSet1"
                    rds.Value = list
                    .LocalReport.DataSources.Clear()
                    .LocalReport.DataSources.Add(rds)
                    .LocalReport.Refresh()
                    .DocumentMapCollapsed = True
                    .SetDisplayMode(DisplayMode.PrintLayout)
                    .RefreshReport()
                End With
                .ShowDialog(Me)
            End With
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If Not ID = Nothing Then
            cert.deleteCertification(ID)
            fillList()
            clear()
            ID = Nothing
        Else
            MsgBox("No data selected")
            Exit Sub
        End If
    End Sub
End Class
