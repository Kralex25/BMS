﻿Public Class OfficialsClass : Inherits DBClass
    Private _id As Integer
    Private _lname, _fname, _mi, _email, _contact, _gender, _age, _position, _civil, _address, _birthdate As String

    Public Property ID As Integer
        Get
            Return _id
        End Get
        Set(value As Integer)
            _id = value
        End Set
    End Property

    Public Property Lastname As String
        Get
            Return _lname
        End Get
        Set(value As String)
            _lname = value
        End Set
    End Property

    Public Property Firstname As String
        Get
            Return _fname
        End Get
        Set(value As String)
            _fname = value
        End Set
    End Property

    Public Property MI As String
        Get
            Return _mi
        End Get
        Set(value As String)
            _mi = value
        End Set
    End Property

    Public Property Email As String
        Get
            Return _email
        End Get
        Set(value As String)
            _email = value
        End Set
    End Property

    Public Property Contact As String
        Get
            Return _contact
        End Get
        Set(value As String)
            _contact = value
        End Set
    End Property

    Public Property Gender As String
        Get
            Return _gender
        End Get
        Set(value As String)
            _gender = value
        End Set
    End Property

    Public Property Birthdate As String
        Get
            Return _birthdate
        End Get
        Set(value As String)
            _birthdate = value
        End Set
    End Property

    Public Property Age As String
        Get
            Return _age
        End Get
        Set(value As String)
            _age = value
        End Set
    End Property

    Public Property Position As String
        Get
            Return _position
        End Get
        Set(value As String)
            _position = value
        End Set
    End Property

    Public Property CivilStatus As String
        Get
            Return _civil
        End Get
        Set(value As String)
            _civil = value
        End Set
    End Property

    Public Property Address As String
        Get
            Return _address
        End Get
        Set(value As String)
            _address = value
        End Set
    End Property

    Public Function GetAllOfficials() As List(Of OfficialsClass)
        Dim list As New List(Of OfficialsClass)
        sql = "SELECT * from officials"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim official As New OfficialsClass
                    official.ID = rdr("officialid")
                    official.Lastname = rdr("lname")
                    official.Firstname = rdr("fname")
                    official.MI = rdr("mi")
                    official.Email = rdr("email")
                    official.Contact = rdr("contact")
                    official.Address = rdr("address")
                    official.Gender = rdr("gender")
                    official.Birthdate = rdr("birthdate")
                    official.Age = rdr("age")
                    official.Position = rdr("position")
                    official.CivilStatus = rdr("civilstatus")
                    list.Add(official)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllOfficials: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetAllOfficialByID(ByVal ID As Integer) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * from officials WHERE officialid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim official As New OfficialsClass
                    official.ID = rdr("officialid")
                    official.Lastname = rdr("lname")
                    official.Firstname = rdr("fname")
                    official.MI = rdr("mi")
                    official.Email = rdr("email")
                    official.Contact = rdr("contact")
                    official.Address = rdr("address")
                    official.Gender = rdr("gender")
                    official.Birthdate = rdr("birthdate")
                    official.Age = rdr("age")
                    official.Position = rdr("position")
                    official.CivilStatus = rdr("civilstatus")
                    list.Add(official)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllOfficialByID: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Function addOfficial() As Boolean
        If Connect() Then
            sql = "INSERT INTO officials(fname,lname,mi,address,email,contact,gender,birthdate,age,[position],civilstatus)" & _
                  "VALUES(@fname,@lname,@mi,@address,@email,@contact,@gender,@birthdate,@age,@position,@civil)"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@fname", Firstname)
                .AddWithValue("@lname", Lastname)
                .AddWithValue("@mi", MI)
                .AddWithValue("@address", Address)
                .AddWithValue("@email", Email)
                .AddWithValue("@contact", Contact)
                .AddWithValue("@gender", Gender)
                .AddWithValue("@birthdate", Birthdate)
                .AddWithValue("@age", Age)
                .AddWithValue("@position", Position)
                .AddWithValue("@civil", CivilStatus)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addPosition: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function


    Function updateOfficial(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE officials SET fname=@fname,lname=@lname,mi=@mi,address=@address,email=@email,contact=@contact," & _
                  "gender=@gender,birthdate=@birthdate,age=@age,[position]=@position,civilstatus=@civil " & _
                  "WHERE officialid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@fname", Firstname)
                .AddWithValue("@lname", Lastname)
                .AddWithValue("@mi", MI)
                .AddWithValue("@address", Address)
                .AddWithValue("@email", Email)
                .AddWithValue("@contact", Contact)
                .AddWithValue("@gender", Gender)
                .AddWithValue("@birthdate", Birthdate)
                .AddWithValue("@age", Age)
                .AddWithValue("@position", Position)
                .AddWithValue("@civil", CivilStatus)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updateOfficial: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Public Function deleteOfficial(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "DELETE FROM officials WHERE officialid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("deleteOfficial: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
End Class
