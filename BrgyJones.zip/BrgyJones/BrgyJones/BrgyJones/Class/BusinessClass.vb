﻿Public Class BusinessClass : Inherits DBClass
    Private _businessid As Integer
    Private _name, _owner, _ctc, _cdateissue, _placeissued, _bdateissue As String

    Public Property BusinessID As Integer
        Get
            Return _businessid
        End Get
        Set(value As Integer)
            _businessid = value
        End Set
    End Property

    Public Property Name As String
        Get
            Return _name
        End Get
        Set(value As String)
            _name = value
        End Set
    End Property

    Public Property Owner As String
        Get
            Return _owner
        End Get
        Set(value As String)
            _owner = value
        End Set
    End Property

    Public Property CTC As String
        Get
            Return _ctc
        End Get
        Set(value As String)
            _ctc = value
        End Set
    End Property

    Public Property CDateIssue As String
        Get
            Return _cdateissue
        End Get
        Set(value As String)
            _cdateissue = value
        End Set
    End Property

    Public Property PlaceIssued As String
        Get
            Return _placeissued
        End Get
        Set(value As String)
            _placeissued = value
        End Set
    End Property

    Public Property BDateIssued As String
        Get
            Return _bdateissue
        End Get
        Set(value As String)
            _bdateissue = value
        End Set
    End Property

    Public Function GetAllBusinesses() As List(Of BusinessClass)
        Dim list As New List(Of BusinessClass)
        sql = "SELECT * from businesses"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim bus As New BusinessClass
                    bus.BusinessID = rdr("businessid")
                    bus.Name = rdr("businessname")
                    bus.Owner = rdr("owner")
                    bus.CTC = rdr("ctc")
                    bus.CDateIssue = rdr("cdateissue")
                    bus.PlaceIssued = rdr("placeissue")
                    bus.BDateIssued = rdr("bdateissue")
                    list.Add(bus)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllBusinesses: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetBusinessByID(ByVal ID As Integer) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * from businesses WHERE businessid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim bus As New BusinessClass
                    bus.BusinessID = rdr("businessid")
                    bus.Name = rdr("businessname")
                    bus.Owner = rdr("owner")
                    bus.CTC = rdr("ctc")
                    bus.CDateIssue = rdr("cdateissue")
                    bus.PlaceIssued = rdr("placeissue")
                    bus.BDateIssued = rdr("bdateissue")
                    list.Add(bus)
                End While
            Catch ex As Exception
                MessageBox.Show("GetBusinessByID: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Function addBusiness() As Boolean
        If Connect() Then
            sql = "INSERT INTO businesses(businessname,owner,ctc,cdateissue,placeissue,bdateissue)VALUES" & _
                  "(@name,@owner,@ctc,@cdateissue,@placeissue,@bdateissue)"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@name", Name)
                .AddWithValue("@owner", Owner)
                .AddWithValue("@ctc", CTC)
                .AddWithValue("@cdateissue", CDateIssue)
                .AddWithValue("@placeissue", PlaceIssued)
                .AddWithValue("@bdateissue", BDateIssued)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addBusiness: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function updateBusiness(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE businesses SET businessname=@name,owner=@owner,ctc=@ctc,cdateissue=@cdateissue," & _
                  "placeissue=@placeissue,bdateissue=@bdateissue WHERE businessid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@name", Name)
                .AddWithValue("@owner", Owner)
                .AddWithValue("@ctc", CTC)
                .AddWithValue("@cdateissue", CDateIssue)
                .AddWithValue("@placeissue", PlaceIssued)
                .AddWithValue("@bdateissue", BDateIssued)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updateBusiness: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function deleteBusiness(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "DELETE FROM businesses WHERE businessid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("deleteBusiness: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
End Class
