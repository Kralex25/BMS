﻿Public Class CertificationsClass : Inherits DBClass
    Private _certificationid As Integer
    Private _applicant, _civilstatus, _length, _dateissued As String

    Public Property CertificationID As Integer
        Get
            Return _certificationid
        End Get
        Set(value As Integer)
            _certificationid = value
        End Set
    End Property

    Public Property Applicant As String
        Get
            Return _applicant
        End Get
        Set(value As String)
            _applicant = value
        End Set
    End Property

    Public Property CivilStatus As String
        Get
            Return _civilstatus
        End Get
        Set(value As String)
            _civilstatus = value
        End Set
    End Property

    Public Property Length As String
        Get
            Return _length
        End Get
        Set(value As String)
            _length = value
        End Set
    End Property

    Public Property DateIssued As String
        Get
            Return _dateissued
        End Get
        Set(value As String)
            _dateissued = value
        End Set
    End Property

    Public Function GetAllCertifications() As List(Of CertificationsClass)
        Dim list As New List(Of CertificationsClass)
        sql = "SELECT * from certifications"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim cert As New CertificationsClass
                    cert.CertificationID = rdr("certificationid")
                    cert.Applicant = rdr("applicant")
                    cert.CivilStatus = rdr("civilstatus")
                    cert.Length = rdr("length")
                    cert.DateIssued = rdr("dateissued")
                    list.Add(cert)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllCertifications: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetCertificationByID(ByVal ID As Integer) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * from certifications WHERE certificationid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim cert As New CertificationsClass
                    cert.CertificationID = rdr("certificationid")
                    cert.Applicant = rdr("applicant")
                    cert.CivilStatus = rdr("civilstatus")
                    cert.Length = rdr("length")
                    cert.DateIssued = rdr("dateissued")
                    list.Add(cert)
                End While
            Catch ex As Exception
                MessageBox.Show("GetCertificationByID: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Function addCertification() As Boolean
        If Connect() Then
            sql = "INSERT INTO certifications(applicant,civilstatus,length,dateissued)VALUES" & _
                  "(@applicant,@civilstatus,@length,@dateissued)"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@applicant", Applicant)
                .AddWithValue("@civilstatus", CivilStatus)
                .AddWithValue("@length", Length)
                .AddWithValue("@dateissued", DateIssued)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addCertification: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function updateCertification(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE certifications SET applicant=@applicant,civilstatus=@civilstatus,length=@length," & _
                  "dateissued=@dateissued WHERE certificationid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@applicant", Applicant)
                .AddWithValue("@civilstatus", CivilStatus)
                .AddWithValue("@length", Length)
                .AddWithValue("@dateissued", DateIssued)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updateCertification: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function deleteCertification(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "DELETE FROM certifications WHERE certificationid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("deleteCertification: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
End Class
