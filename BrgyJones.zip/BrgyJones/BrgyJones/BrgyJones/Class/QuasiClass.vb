﻿Public Class QuasiClass : Inherits DBClass


End Class
