﻿Public Class SeniorsClass : Inherits DBClass
    Private _seniorid As Integer
    Private _lname, _fname, _mi, _address, _birthdate, _stipend As String

    Public Property SeniorID As Integer
        Get
            Return _seniorid
        End Get
        Set(value As Integer)
            _seniorid = value
        End Set
    End Property

    Public Property LastName As String
        Get
            Return _lname
        End Get
        Set(value As String)
            _lname = value
        End Set
    End Property

    Public Property FirstName As String
        Get
            Return _fname
        End Get
        Set(value As String)
            _fname = value
        End Set
    End Property

    Public Property MI As String
        Get
            Return _mi
        End Get
        Set(value As String)
            _mi = value
        End Set
    End Property

    Public Property Address As String
        Get
            Return _address
        End Get
        Set(value As String)
            _address = value
        End Set
    End Property

    Public Property Birthdate As String
        Get
            Return _birthdate
        End Get
        Set(value As String)
            _birthdate = value
        End Set
    End Property

    Public Property Stipend As String
        Get
            Return _stipend
        End Get
        Set(value As String)
            _stipend = value
        End Set
    End Property



    Public Function GetAllSeniors() As List(Of SeniorsClass)
        Dim list As New List(Of SeniorsClass)
        sql = "SELECT * from seniors"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim Sen As New SeniorsClass
                    Sen.SeniorID = rdr("seniorid")
                    Sen.LastName = rdr("lname")
                    Sen.FirstName = rdr("fname")
                    Sen.MI = rdr("mi")
                    Sen.Address = rdr("address")
                    Sen.Birthdate = rdr("birthdate")
                    Sen.Stipend = rdr("stipend")
                    list.Add(Sen)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllSeniors: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetSeniorByID(ByVal ID As Integer) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * from seniors WHERE seniorid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim Sen As New SeniorsClass
                    Sen.SeniorID = rdr("seniorid")
                    Sen.LastName = rdr("lname")
                    Sen.FirstName = rdr("fname")
                    Sen.MI = rdr("mi")
                    Sen.Address = rdr("address")
                    Sen.Birthdate = rdr("birthdate")
                    Sen.Stipend = rdr("stipend")
                    list.Add(Sen)
                End While
            Catch ex As Exception
                MessageBox.Show("GetSeniorByID: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Function addSenior() As Boolean
        If Connect() Then
            sql = "INSERT INTO seniors(lname,fname,mi,address,birthdate,stipend)VALUES" & _
                  "(@lname,@fname,@mi,@address,@birthdate,@stipend)"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@lname", LastName)
                .AddWithValue("@fname", FirstName)
                .AddWithValue("@mi", MI)
                .AddWithValue("@address", Address)
                .AddWithValue("@birthdate", Birthdate)
                .AddWithValue("@stipend", Stipend)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addSenior: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function updateSenior(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE seniors  SET lname=@lname,fname=@fname,mi=@mi,address=@address,birthdate=@birthdate," & _
                  "stipend=@stipend WHERE seniorid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@lname", LastName)
                .AddWithValue("@fname", FirstName)
                .AddWithValue("@mi", MI)
                .AddWithValue("@address", Address)
                .AddWithValue("@birthdate", Birthdate)
                .AddWithValue("@stipend", Stipend)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updateSenior: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function deleteSenior(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "DELETE FROM seniors WHERE seniorid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("deleteSenior: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
End Class
