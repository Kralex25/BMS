﻿Imports System.Data.OleDb
Public Class DBClass
    Public cn As New OleDbConnection
    Public cmd As OleDbCommand
    Public rdr As OleDbDataReader
    Public sql As String = String.Empty
    Public Function Connect() As Boolean
        cn.ConnectionString = "Provider=Microsoft.JET.OLEDB.4.0;Data Source=" & Application.StartupPath & "\brgydb.mdb"
        Try
            cn.Open()
            Return True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
            Return False
        End Try
    End Function
End Class
