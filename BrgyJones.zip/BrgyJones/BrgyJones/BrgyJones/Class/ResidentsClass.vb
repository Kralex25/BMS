﻿Public Class ResidentsClass : Inherits DBClass
    Private _residentid As Integer
    Private _fname, _mi, _lname, _purok, _street, _contact, _work, _gender, _birthdate, _age, _civilstatus As String

    Public Property ResidentID As Integer
        Get
            Return _residentid
        End Get
        Set(value As Integer)
            _residentid = value
        End Set
    End Property

    Public Property Firstname As String
        Get
            Return _fname
        End Get
        Set(value As String)
            _fname = value
        End Set
    End Property

    Public Property Lastname As String
        Get
            Return _lname
        End Get
        Set(value As String)
            _lname = value
        End Set
    End Property

    Public Property MI As String
        Get
            Return _mi
        End Get
        Set(value As String)
            _mi = value
        End Set
    End Property

    Public Property Purok As String
        Get
            Return _purok
        End Get
        Set(value As String)
            _purok = value
        End Set
    End Property

    Public Property Street As String
        Get
            Return _street
        End Get
        Set(value As String)
            _street = value
        End Set
    End Property

    Public Property Contact As String
        Get
            Return _contact
        End Get
        Set(value As String)
            _contact = value
        End Set
    End Property

    Public Property Work As String
        Get
            Return _work
        End Get
        Set(value As String)
            _work = value
        End Set
    End Property

    Public Property Gender As String
        Get
            Return _gender
        End Get
        Set(value As String)
            _gender = value
        End Set
    End Property

    Public Property Birthdate As String
        Get
            Return _birthdate
        End Get
        Set(value As String)
            _birthdate = value
        End Set
    End Property

    Public Property Age As String
        Get
            Return _age
        End Get
        Set(value As String)
            _age = value
        End Set
    End Property

    Public Property CivilStatus As String
        Get
            Return _civilstatus
        End Get
        Set(value As String)
            _civilstatus = value
        End Set
    End Property

    Public Function GetAllResidents() As List(Of ResidentsClass)
        Dim list As New List(Of ResidentsClass)
        sql = "SELECT * from residents"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim res As New ResidentsClass
                    res.ResidentID = rdr("residentid")
                    res.Lastname = rdr("lname")
                    res.Firstname = rdr("fname")
                    res.MI = rdr("mi")
                    res.Purok = rdr("purok")
                    res.Street = rdr("street")
                    res.Contact = rdr("contact")
                    res.Work = rdr("work")
                    res.Gender = rdr("gender")
                    res.Birthdate = rdr("birthdate")
                    res.Age = rdr("age")
                    res.CivilStatus = rdr("civilstatus")
                    list.Add(res)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllOfficials: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetResidentsByID(ByVal ID As Integer) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * from residents WHERE residentid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim res As New ResidentsClass
                    res.ResidentID = rdr("residentid")
                    res.Lastname = rdr("lname")
                    res.Firstname = rdr("fname")
                    res.MI = rdr("mi")
                    res.Purok = rdr("purok")
                    res.Street = rdr("street")
                    res.Contact = rdr("contact")
                    res.Work = rdr("work")
                    res.Gender = rdr("gender")
                    res.Birthdate = rdr("birthdate")
                    res.Age = rdr("age")
                    res.CivilStatus = rdr("civilstatus")
                    list.Add(res)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllOfficials: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Function addResident() As Boolean
        If Connect() Then
            sql = "INSERT INTO residents(fname,lname,mi,purok,street,[contact],[work],[gender],birthdate,[age],civilstatus)" & _
                  "VALUES(@fname,@lname,@mi,@purok,@street,@contact,@work,@gender,@birthdate,@age,@civil)"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@fname", Firstname)
                .AddWithValue("@lname", Lastname)
                .AddWithValue("@mi", MI)
                .AddWithValue("@purok", Purok)
                .AddWithValue("@street", Street)
                .AddWithValue("@contact", Contact)
                .AddWithValue("@work", Work)
                .AddWithValue("@gender", Gender)
                .AddWithValue("@birthdate", Birthdate)
                .AddWithValue("@age", Age)
                .AddWithValue("@civil", CivilStatus)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addResident: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function updateResident(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE residents SET fname=@fname,lname=@lname,mi=@mi,purok=@purok,street=@street," & _
                  "[contact]=@contact,[work]=@work,[gender]=@gender,birthdate=@birthdate,[age]=@age,civilstatus=@civil " & _
                  "WHERE residentid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@fname", Firstname)
                .AddWithValue("@lname", Lastname)
                .AddWithValue("@mi", MI)
                .AddWithValue("@purok", Purok)
                .AddWithValue("@street", Street)
                .AddWithValue("@contact", Contact)
                .AddWithValue("@work", Work)
                .AddWithValue("@gender", Gender)
                .AddWithValue("@birthdate", Birthdate)
                .AddWithValue("@age", Age)
                .AddWithValue("@civil", CivilStatus)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updateResident: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function


    Function deleteResident(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "DELETE FROM residents WHERE residentid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("deleteResident: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
End Class
