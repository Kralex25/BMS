﻿Public Class IndigenciesClass : Inherits DBClass
    Private _indigencyid As Integer
    Private _applicant, _dateissued As String

    Public Property IndigencyID As Integer
        Get
            Return _indigencyid
        End Get
        Set(value As Integer)
            _indigencyid = value
        End Set
    End Property

    Public Property Applicant As String
        Get
            Return _applicant
        End Get
        Set(value As String)
            _applicant = value
        End Set
    End Property

    Public Property DateIssued As String
        Get
            Return _dateissued
        End Get
        Set(value As String)
            _dateissued = value
        End Set
    End Property

    Public Function GetAllIndigencies() As List(Of IndigenciesClass)
        Dim list As New List(Of IndigenciesClass)
        sql = "SELECT * from indigencies"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim ind As New IndigenciesClass
                    ind.IndigencyID = rdr("indigencyid")
                    ind.Applicant = rdr("applicant")
                    ind.DateIssued = rdr("dateissued")
                    list.Add(ind)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllIndigencies: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetIndigenciesByID(ByVal ID As Integer) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * from indigencies WHERE indigencyid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim ind As New IndigenciesClass
                    ind.IndigencyID = rdr("indigencyid")
                    ind.Applicant = rdr("applicant")
                    ind.DateIssued = rdr("dateissued")
                    list.Add(ind)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllIndigencies: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Function addIndigency() As Boolean
        If Connect() Then
            sql = "INSERT INTO indigencies(applicant,dateissued)VALUES" & _
                  "(@applicant,@dateissued)"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@applicant", Applicant)
                .AddWithValue("@dateissued", DateIssued)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addIndigency: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function updateIndigency(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE indigencies SET applicant=@applicant," & _
                  "dateissued=@dateissued WHERE indigencyid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@applicant", Applicant)
                .AddWithValue("@dateissued", DateIssued)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updateIndigency: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function deleteIndigency(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "DELETE FROM indigencies WHERE indigencyid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("deleteIndigency: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
End Class
