﻿Public Class UsersClass : Inherits DBClass
    Private _userid As Integer
    Private _username, _password As String

    Public Property UserID As Integer
        Get
            Return _userid
        End Get
        Set(value As Integer)
            _userid = value
        End Set
    End Property

    Public Property Username As String
        Get
            Return _username
        End Get
        Set(value As String)
            _username = value
        End Set
    End Property

    Public Property Password As String
        Get
            Return _password
        End Get
        Set(value As String)
            _password = value
        End Set
    End Property

    Public Function GetAllUsers() As List(Of UsersClass)
        Dim list As New List(Of UsersClass)
        sql = "SELECT * from users"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim user As New UsersClass
                    user.UserID = rdr("userid")
                    user.Username = rdr("uname")
                    user.Password = rdr("pword")
                    list.Add(user)
                End While
            Catch ex As Exception
                MessageBox.Show("GetAllUsers: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function GetUserByID(ByVal ID As Integer) As ArrayList
        Dim list As New ArrayList
        sql = "SELECT * from users WHERE userid=@id"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                rdr = cmd.ExecuteReader()
                While rdr.Read
                    Dim user As New UsersClass
                    user.UserID = rdr("userid")
                    user.Username = rdr("uname")
                    user.Password = rdr("pword")
                    list.Add(user)
                End While
            Catch ex As Exception
                MessageBox.Show("GetUserByID: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return list
    End Function

    Public Function LogUser(ByVal Uname As String, ByVal Pword As String) As Boolean
        sql = "SELECT * from users WHERE uname=@uname AND pword=@pword"
        If Connect() Then
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@uname", Uname)
                .AddWithValue("@pword", Pword)
            End With
            Try
                rdr = cmd.ExecuteReader()
                If rdr.HasRows Then
                    Return True
                End If
            Catch ex As Exception
                MessageBox.Show("LogUser: " & ex.Message)
                Return False
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function addUser() As Boolean
        If Connect() Then
            sql = "INSERT INTO users(uname,pword)VALUES" & _
                  "(@username,@password)"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@username", Username)
                .AddWithValue("@password", Password)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("addUser: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function updateUser(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "UPDATE [users] SET uname=@username,pword=@password WHERE userid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@username", Username)
                .AddWithValue("@password", Password)
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show("updateUser: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function

    Function deleteUser(ByVal ID As Integer) As Boolean
        If Connect() Then
            sql = "DELETE FROM users WHERE userid=@id"
            cmd = New OleDb.OleDbCommand(sql, cn)
            With cmd.Parameters
                .AddWithValue("@id", ID)
            End With
            Try
                cmd.ExecuteNonQuery()
                Return True
            Catch ex As Exception
                MessageBox.Show(" deleteUser: " & ex.Message)
            Finally
                cmd.Dispose()
                cn.Close()
            End Try
        End If
        Return False
    End Function
End Class
